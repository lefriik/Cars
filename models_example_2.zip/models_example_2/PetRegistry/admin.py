from django.contrib import admin

from .models import Pet
# Register your models here.
admin.site.register(Pet)